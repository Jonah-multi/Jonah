# mixed alphabet substitution dictionary
sub = {
  # letters
  'a':'o', 'b':'f', 'c':'e',
  'd':'q', 'e':'w', 'f':'s',
  'g':'d', 'h':'h', 'i':'r',
  'j':'u', 'k':'b', 'l':'k',
  'm':'m', 'n':'v', 'o':'y',
  'p':'l', 'q':'i', 'r':'x',
  's':'z', 't':'t', 'u':'n',
  'v':'p', 'w':'a', 'x':'c',
  'y':'j', 'z':'g',
  'A':'O', 'B':'F', 'C':'E',
  'D':'Q', 'E':'W', 'F':'S',
  'G':'D', 'H':'H', 'I':'R',
  'J':'U', 'K':'B', 'L':'K',
  'M':'M', 'N':'V', 'O':'Y',
  'P':'L', 'Q':'I', 'R':'X',
  'S':'Z', 'T':'T', 'U':'N',
  'V':'P', 'W':'A', 'X':'C',
  'Y':'J', 'Z':'G',
  # digits
  '1':'1', '2':'2', '3':'3',
  '4':'4', '5':'5', '6':'6',
  '7':'7', '8':'8', '9':'9',
  # punctuation
  ' ':' ', ',':',', '.':'.',
  '"':'"',  "'":"'",'-':'-',
  '?':'?', '!':'!', ';':';',
  ':':':', '(':'(', ')':')',
  '’':'’', '—':'—', '“':'“',
  '”':'”',
}
subb = {
  # letters
  'o':'a', 'f':'b', 'e':'c',
  'q':'d', 'w':'e', 's':'f',
  'd':'g', 'h':'h', 'r':'i',
  'u':'j', 'b':'k', 'k':'l',
  'm':'m', 'v':'n', 'y':'o',
  'l':'p', 'i':'q', 'x':'r',
  'z':'s', 't':'t', 'n':'u',
  'p':'v', 'a':'w', 'c':'x',
  'j':'y', 'g':'z',
  'O':'A', 'F':'B', 'E':'C',
  'Q':'D', 'W':'E', 'S':'F',
  'D':'G', 'H':'H', 'R':'I',
  'U':'J', 'B':'K', 'K':'L',
  'M':'M', 'V':'N', 'Y':'O',
  'L':'P', 'I':'Q', 'X':'R',
  'Z':'S', 'T':'T', 'N':'U',
  'P':'V', 'A':'W', 'C':'X',
  'J':'Y', 'G':'Z',
  # digits
  '1':'1', '2':'2', '3':'3',
  '4':'4', '5':'5', '6':'6',
  '7':'7', '8':'8', '9':'9',
  # punctuation
  ' ':' ', ',':',', '.':'.',
  '"':'"',  "'":"'",'-':'-',
  '?':'?', '!':'!', ';':';',
  ':':':', '(':'(', ')':')',
  '’':'’', '—':'—', '“':'“',
  '”':'”',
}
MORSE_CODE_DICT = { 'A':'.-', 'B':'-...', 
                    'C':'-.-.', 'D':'-..', 'E':'.', 
                    'F':'..-.', 'G':'--.', 'H':'....', 
                    'I':'..', 'J':'.---', 'K':'-.-', 
                    'L':'.-..', 'M':'--', 'N':'-.', 
                    'O':'---', 'P':'.--.', 'Q':'--.-', 
                    'R':'.-.', 'S':'...', 'T':'-', 
                    'U':'..-', 'V':'...-', 'W':'.--', 
                    'X':'-..-', 'Y':'-.--', 'Z':'--..', 
                    '1':'.----', '2':'..---', '3':'...--', 
                    '4':'....-', '5':'.....', '6':'-....', 
                    '7':'--...', '8':'---..', '9':'----.', 
                    '0':'-----', ', ':'--..--', '.':'.-.-.-', 
                    '?':'..--..', '/':'-..-.', '-':'-....-', 
                    '(':'-.--.', ')':'-.--.-'} 
# Function to encrypt the string 
# according to the morse code chart 
def encrypt(message): 
    cipher = '' 
    for letter in message: 
        if letter != ' ': 
  
            # Looks up the dictionary and adds the 
            # correspponding morse code 
            # along with a space to separate 
            # morse codes for different characters 
            cipher += MORSE_CODE_DICT[letter] + ' '
        else: 
            # 1 space indicates different characters 
            # and 2 indicates different words 
            cipher += ' '
  
    return cipher 
  
# Function to decrypt the string 
# from morse to english 
def decrypt(message): 
  
    # extra space added at the end to access the 
    # last morse code 
    message += ' '
  
    decipher = '' 
    citext = '' 
    for letter in message: 
  
        # checks for space 
        if (letter != ' '): 
  
            # counter to keep track of space 
            i = 0
  
            # storing morse code of a single character 
            citext += letter 
  
        # in case of space 
        else: 
            # if i = 1 that indicates a new character 
            i += 1
  
            # if i = 2 that indicates a new word 
            if i == 2 : 
  
                 # adding space to separate words 
                decipher += ' '
            else: 
  
                # accessing the keys using their values (reverse of encryption) 
                decipher += list(MORSE_CODE_DICT.keys())[list(MORSE_CODE_DICT 
                .values()).index(citext)] 
                citext = '' 
  
    return decipher


def int2bytes(i):
    hex_string = '%x' % i
    n = len(hex_string)
    return binascii.unhexlify(hex_string.zfill(n + (n & 1)))

def rotate_alpha_key(letter, key, direction):
  if letter.islower():
    shift = ord(key) - ord('a')
    if direction == '+':
      new = ord(letter) + shift
    else:
      new = ord(letter) - shift
    if new > ord('z'):
      new = new - 26
    elif new < ord('a'):
      new = new + 26
    new = chr(new)
  else:
    new = letter
  return new

def rotate_number_key(letter, key):
  if letter.islower():
    new = ord(letter) + key
    if new > ord('z'):
      new = new - 26
    elif new < ord('a'):
      new = new + 26
    new = chr(new)
  else:
    new = letter
  return new

def xor(character, key):
  code = ord(character) ^ ord(key)
  result = chr(code)
  return result

def get_file_contents(filename):
  with open(filename, 'r') as f:
   contents = f.read().strip()
  return contents
