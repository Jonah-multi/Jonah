from crypto import *
from functions import get_file_contents

if __name__ == '__main__':
  
  d = int(input("0 = rot, 1 = xor, 2 = mixed alphabet, 3 = vigenere. "))
  if d == 2:
    message = input('What is the message: ')
    t = int(input('0 = encrypt, 1 = decrypt: '))
    if t == 0:
      encrypted = (encrypt_mixed_sub(message))
      print(encrypted)
      f = open('encrypt.txt', 'w+')
      f.write(encrypted)
    elif t == 1:
      decrypted = (decrypt_mixed_sub(message))
      print(decrypted)
      n = open('decrypt.txt', 'w+')
      n.write(decrypted)

  elif d == 0:
    # rot cipher
    message = str(input('What is the message: '))
    key = int(input('What is the number: '))
    t = int(input('0 = encrypt, 1 = decrypt: ')) 
    if t == 0: 
      encrypted = encrypt_rot(message, key)
      print(encrypted)
      f = open('encrypt.txt', 'w+')
      f.write(encrypted)
    elif t == 1:
      decrypted = decrypt_rot(message, key)
      print(decrypted)
      n = open('decrypt.txt', 'w+')
      n.write(decrypted)
  elif d == 1:
    # xor cipher
     
    message = input("What is your message: ")
    key = input("What is your single character key: ")
    t = int(input("0 = encrypt, 1 = decrypt: "))
    if t == 0:
          encrypted = encrypt_xor(message, key)
          print(encrypted)
          f = open('encrypt.txt', 'w+')
          f.write(encrypted)
    elif t == 1:
          decrypted = decrypt_xor(message, key)
          print(decrypted)
          n = open('decrypt.txt', 'w+')
          n.write(decrypted)
  #f = open('encrypt.txt', 'w+')
  #f.write(encrypted)
  #n = open('decrypt.txt', 'w+')
  #n.write(decrypted)
  elif d == 3:
    # vigenere cipher
    message = input("What is the message: ")
    key = input("What is the key: ")
    t = int(input("0 = encrypt, 1 = decrypt: "))
    if t == 0:
      encrypted = ''
      encrypted = encrypted + encrypt_vigenere(message, key)
      print (encrypted)
      f = open('encrypt.txt', 'w+')
      f.write(encrypted)
    elif t == 1:
      decrypted = ''
      decrypted = decrypted + decrypt_vigenere(message, key)
      print (decrypted)
      n = open('decrypt.txt', 'w+')
      n.write(decrypted)