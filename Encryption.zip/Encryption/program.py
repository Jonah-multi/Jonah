from crypto import *
from functions import get_file_contents
import base64
if __name__ == '__main__':
  d = int(input("0 = ROT, 1 = XOR, 2 = Mixed Alphabet, 3 = Vigenere, 4 = Hexadecimal, 5 = Base64, 6 = Binary, 7 = Morse Code. "))
  if d == 5:
    message = input('What is the message: ')
    t = int(input("0 = encrypt, 1 = decrypt: "))
    if t == 0:
      f = message.encode('ascii')
      encoded = base64.b64encode(f)
      print (encoded)
      f = encoded.decode()
      q = open('encrypt.txt', 'w+')
      q.write(str(encoded))
    elif t == 1:
      f = base64.b64decode(message)
      print (f)
      decoded = str(f)
      n = open('decrypt.txt', 'w')
      n.write(decoded)
  
  if d == 2:
    message = input('What is the message: ')
    t = int(input('0 = encrypt, 1 = decrypt: '))
    if t == 0:
      encrypted = (encrypt_mixed_sub(message))
      print(encrypted)
      f = open('encrypt.txt', 'w+')
      f.write(encrypted)
    elif t == 1:
      decrypted = (decrypt_mixed_sub(message))
      print(decrypted)
      n = open('decrypt.txt', 'w+')
      n.write(decrypted)

  elif d == 0:
    # rot cipher
    message = str(input('What is the message: '))
    key = int(input('What is the number: '))
    t = int(input('0 = encrypt, 1 = decrypt: ')) 
    if t == 0: 
      encrypted = encrypt_rot(message, key)
      print(encrypted)
      f = open('encrypt.txt', 'w+')
      f.write(encrypted)
    elif t == 1:
      decrypted = decrypt_rot(message, key)
      print(decrypted)
      n = open('decrypt.txt', 'w+')
      n.write(decrypted)
  elif d == 1:
    # xor cipher
     
    message = input("What is your message: ")
    key = input("What is your single character key: ")
    t = int(input("0 = encrypt, 1 = decrypt: "))
    if t == 0:
          encrypted = encrypt_xor(message, key)
          print(encrypted)
          f = open('encrypt.txt', 'w+')
          f.write(encrypted)
    elif t == 1:
          decrypted = decrypt_xor(message, key)
          print(decrypted)
          n = open('decrypt.txt', 'w+')
          n.write(decrypted)
  #f = open('encrypt.txt', 'w+')
  #f.write(encrypted)
  #n = open('decrypt.txt', 'w+')
  #n.write(decrypted)
  elif d == 4:
    message = input("What is your message: ")
    t = int(input("0 = encrypt, 1 = decrypt: "))
    if t == 0:
      g = ''
      for c in message:
          g = g+(''.join(hex(ord(c)))[2:])+' '
      print (g)
      f = open('encrypt.txt', 'w+')
      f.write(g)
    elif t == 1:
      c = bytes.fromhex(message).decode('utf-8')
      print (c)
      n = open('decrypt.txt', 'w+')
      n.write(c)

  elif d == 3:
    # vigenere cipher
    message = input("What is the message: ")
    key = input("What is the key: ")
    t = int(input("0 = encrypt, 1 = decrypt: "))
    if t == 0:
      encrypted = ''
      encrypted = encrypted + encrypt_vigenere(message, key)
      print (encrypted)
      f = open('encrypt.txt', 'w+')
      f.write(encrypted)
    elif t == 1:
      decrypted = ''
      decrypted = decrypted + decrypt_vigenere(message, key)
      print (decrypted)
      n = open('decrypt.txt', 'w+')
      n.write(decrypted)
  elif d == 6:
    message = input("What is the message: ")
    t = int(input("0 = encrypt, 1 = decrypt: "))
    if t == 0:
      encrypted = bin(int.from_bytes(message.encode(), 'big'))
      print (encrypted)
      encrypt = str(encrypted)
      f = open('encrypt.txt', 'w+')
      f.write(encrypt)
    elif t == 1:
    
      
      str = (message)
      str = "0" + str[2:]
      decrypted = ""
      while str != "":
          i = chr(int(str[:8], 2))
          decrypted = decrypted + i
          str = str[8:]
      print (decrypted)
      n = open('decrypt.txt', 'w+')
      n.write(decrypted)
  
  elif d == 7:
    message = input('What is the message: ')
    t = int(input("0 = encrypt, 1 = decrypt: "))

    if t == 0:
        encrypted = encrypt(message.upper()) 
        print (encrypted)
        f = open('encrypt.txt', 'w+')
        f.write(encrypted)
    elif t == 1:
        decrypted = decrypt(message) 
        print (decrypted)
        n = open('decrypt.txt', 'w+')
        n.write(decrypted)
